#ifndef _BEEP_H
#define _BEEP_H

#include "sys.h"

#define BEE PBout(3)
void beep_init(void);

#endif
